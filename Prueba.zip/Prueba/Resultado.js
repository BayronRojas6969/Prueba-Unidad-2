function Registrar(){
  //Datos que ingresará el USUARIO
    var nombre = document.getElementsByName("nombre")[0].value;
    var nota_1 = document.getElementsByName("nota1")[0].value;
    var nota_2 = document.getElementsByName("nota2")[0].value;
    var nota_3 = document.getElementsByName("nota3")[0].value;
    var nota_4 = document.getElementsByName("nota4")[0].value;
    var nota_5 = document.getElementsByName("nota5")[0].value;
    var nota_6 = document.getElementsByName("nota6")[0].value;
    var carrera = document.getElementsByName("carrera")[0].value;
    
    var v_nombre = document.getElementById("verificar_nombre");
    var v_nota1 = document.getElementById("verificar_nota1");
    var v_nota2 = document.getElementById("verificar_nota2");
    var v_nota3 = document.getElementById("verificar_nota3");
    var v_nota4 = document.getElementById("verificar_nota4");
    var v_nota5 = document.getElementById("verificar_nota5");
    var v_nota6 = document.getElementById("verificar_nota6");
    var v_carrera = document.getElementById("verificar_carrera");
    var pro = document.getElementById("promedio");


    var pro =(parseFloat(nota_1)+parseFloat(nota_2)+parseFloat(nota_3)+parseFloat(nota_4)+parseFloat(nota_5)+parseFloat(nota_6))/6
    document.getElementById("promedio").innerHTML = pro;
 

    if(!/^[A-Za-zÁÉÍÓÚáéíóúÑñ]*$/.test(nombre) || nombre === "" || nombre.length > 20 || nombre.length < 3){
        alert ("Mensaje no enviado, revisa los datos ingresados.")
        
        v_nombre.innerHTML = "Error al registrar Nombre";
      }else{ 
        v_nombre.innerHTML = "Nombre Registrado con Exito" 
    

      }if(nota_1<1 || nota_1>7){
        v_nota1.innerHTML= "Datos de nota  1 invalidos"
    }else if(nota_1){
      v_nota1


      }if(nota_2<1 || nota_2>7){
        v_nota2.innerHTML= "Datos de nota  2 invalidos"
    }else if(nota_2){
      v_nota2


      }if(nota_3<1 || nota_3>7){
        v_nota3.innerHTML= "Datos de nota  3 invalidos"
    }else if(nota_3){
      v_nota3


      }if(nota_4<1 || nota_4>7){
        v_nota6.innerHTML= "Datos de nota  4 invalidos"
    }else if(nota_4){
      v_nota4


      }if(nota_5<1 || nota_5>7){
        v_nota5.innerHTML= "Datos de nota  5 invalidos"
    }else if(nota_5){
      v_nota5


      }if(nota_6<1 || nota_6>7){
          v_nota6.innerHTML= "Datos de nota  6 invalidos"
      }else if(nota_6){
        v_nota6

        
      }if(pro < 4.0){
      document.write("<center><h1>Resultados</h1>");
      document.write("<center><h1>Has Reprobado!</h1><br><br>")
      
    }else{
      document.write("<center><h1>Resultados</h1>")
      document.write("<center><h1>Has aprobado La Asignatura!</h1><br><br>")
      
      }

      document.write("<b>Nombre del estudiante:⠀"+nombre,"<br><br>Carrera:"+carrera,"<br><br><h3>Unidad 1 33%</h3>","<br>Tu Nota 1 es:⠀"+nota_1,"<br><br>Tu Nota 2 es:⠀"+nota_2,"<br><br><h3>Unidad 2 33%</h3>","<br>Tu Nota 3 es:⠀"+nota_3,"<br><br>Tu Nota 4 es:⠀"+nota_4,"<br><h3>Unidad 3 34%</h3>","<br>Tu Nota 5 es:⠀"+nota_5,"<br><br>Tu Nota 6 es:⠀"+nota_6,"<br><br>Promedio:⠀"+pro.toFixed(1));
  
      
      }
